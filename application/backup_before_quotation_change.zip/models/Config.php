<?php

define('FIREBASE_API_KEY', 'AIzaSyA0oQeb2Izh8x8m4IbaLU1vTCXH16jNlYA');

?>
