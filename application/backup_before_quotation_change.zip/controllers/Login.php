<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Login extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library("session");
        $this->load->helper("cookie");
		$this->load->model('CookieModel', 'cookie');
    }
    

    public function index()
    {
        // if(isset($_COOKIE['usertype']))
		// {
		// 	$usertype = $this->cookie->getCookie("usertype");
		// 	$id = $this->cookie->getCookie("id");
		// 	if($usertype =="pscadmin")
		// 		redirect(base_url('admin/dashboard'));
        //     else if($usertype == "superadmin")
        //         redirect(base_url('superadmin/dashboard'));
        //     else                
        //         $this->load->view('login'); 
		// }
		// else
            $this->load->view('login');
    }

    public function checklogin()
    { 
        $username = str_replace("'", "''", $this->input->post('username'));
        $password = str_replace("'", "''", $this->input->post('password'));
    
        
        $query = "SELECT * FROM admins WHERE username = '" . $username . "' AND password = '" . $password . "'";
		$data = $this->db->query($query);             
		if ($data->num_rows() > 0) {
			$result = $data->result();
			foreach ($result as $row) {
				$this->load->helper('cookie');
				$this->cookie->setCookie('name', $row->username);
				$this->cookie->setCookie('usertype', 'pscadmin');
                // $this->cookie->setCookie('type', $row->usertype);
				$this->cookie->setCookie('adminid', $row->id);
				redirect(base_url('admin'));
			}
		}
        else if($username == 'superadmin' && $password == 'Forestgump@1901'){
            $this->load->helper('cookie');
            $this->setCookie('usertype', 'superadmin');
            $this->setCookie('id', '0');
            redirect(base_url('superadmin/dashboard'));
        } 
        
		else{
            $this->session->set_flashdata('error_msg', 'Username or password is wrong');
            redirect(base_url('login'));
        }
        

    }
    public function setCookie($name, $value)
    {
        $cookie = array(
            'name' => $name,
            'value' => $value,
            'expire' => '31556926',
        );
        $this->input->set_cookie($cookie);
    }

    public function getCookie($name)
    {
        return $this->input->cookie($name, true);
    }

    public function clearCookie($name)
    {
        $cookie = array(
            'name' => $name,
            'value' => '',
            'expire' => '-3600',
        );
        $this->input->set_cookie($cookie);
    }

    public function logout()
    {
        $this->clearCookie('usertype');
        $this->clearCookie('id');
        $this->session->unset_userdata('usertype');
        $this->session->unset_userdata('id');
        redirect(base_url());
    }

}
