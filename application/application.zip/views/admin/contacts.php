<div class="page-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-sm-6 col-3">
                <h4 class="page-title">Contacts [<?= sizeof($result); ?>]</h4>
            </div>             
        </div>
        <div class="row">
            <div class="col-md-12">                
                <div class="card-box">
                    <form action="<?= base_url('admin/saveContact'); ?>" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?= $id; ?>" />                            
                            <div class="col-sm-12">
                                <div class="row">
                                    
                                    <div class="col-sm-4">
                                        <label>Firm Name <span class="text-danger">*</span></label>
                                            <input class="form-control" name="firmname" id="firmname" value="<?= $id == 0 ? '' : $data->firmname; ?>" type="text" required>
                                    </div>
                                    <div class="col-sm-4">
                                        <label>Name <span class="text-danger">*</span></label>
                                            <input class="form-control" name="name" id="name" value="<?= $id == 0 ? '' : $data->name; ?>" type="text" required>
                                    </div>
                                    <div class="col-sm-4">
                                        <label>City<span class="text-danger">*</span></label>
                                            <input class="form-control" name="city" id="city" value="<?= $id == 0 ? '' : $data->city; ?>" type="text" required>
                                    </div>
                                    <div class="col-sm-8">
                                        <label>Address<span class="text-danger"></span></label>
                                        <textarea class="form-control" rows="1" name="address" id="address"><?= $id == 0 ? '' : $data->address; ?></textarea>  
                                    </div>
                                    <div class="col-sm-4">
                                        <label>State<span class="text-danger">*</span></label>
                                            <input class="form-control" name="state" id="state" value="<?= $id == 0 ? 'Maharastra' : $data->state; ?>" type="text" required>
                                    </div>
                                    <div class="col-sm-3">
                                        <label>Mobile No.1<span class="text-danger">*</span></label>
                                            <input class="form-control" name="mobileno1" id="mobileno1" value="<?= $id == 0 ? '' : $data->mobileno1; ?>" type="text" required>
                                    </div>
                                    <div class="col-sm-3">
                                        <label>Mobile No.2<span class="text-danger"></span></label>
                                            <input class="form-control" name="mobileno2" id="mobileno2" value="<?= $id == 0 ? '' : $data->mobileno2; ?>" type="text" >
                                    </div>
                                    <div class="col-sm-3">
                                        <label>GST No.<span class="text-danger"></span></label>
                                            <input class="form-control" name="gstno" id="" value="<?= $id == 0 ? '' : $data->gstno; ?>" type="text" >
                                    </div>
                                    <div class="col-sm-3">
                                        <label>Profession<span class="text-danger">*</span></label>
                                            <input class="form-control" list="professions" name="profession" id="profession" value="<?= $id == 0 ? '' : $data->profession; ?>" type="text" required>
         
                                    <datalist id="professions">
                                        <option value="Steel Trader">
                                        <option value="Civil Engineer">
                                        <option value="Purchase Head">
                                        <option value="Stone Crusher">
                                        <option value="End User">
                                    </datalist>
                                    </div>
                                    
                                    <div class="col-sm-12 text-right">
                                        <br />                                        
                                        <a href="<?= base_url('admin/contacts/0'); ?>" class="btn btn-danger">Cancel</a>
                                        <button class="btn btn-primary">Save</button>
                                    </div>
                                </div>
                            </div>
                    </form>
                </div>
            </div>
            <div class="col-md-12">
                <input type="text" id="myInput" onkeyup="myFunction()" class="form-control"  placeholder="Search..." autocomplete="off"> 
                <br />
                <input type="button" onclick="tableToExcel('myTable', 'W3C Example Table')"  class="btn btn btn-danger btn-rounded float-right" value="Export">
                    <div class="table-responsive">
                        <table class="table table-striped custom-table" id="myTable">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Firm Details</th>
                                    <th>Address</th>
                                    <th>City</th>
                                    <th>Contact Details</th>
                                    <th>Profession</th>
                                    <th>GST No.</th>
                                    <th>Action</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $count = 1;
                                    if(isset($result)){

                                        
                                    foreach ($result as $row) {
                                ?>
                                <tr>
                                    <td><?= $count; ?></td>
                                    
                                    <td><?= $row->firmname;?></td>
                                    <td><?= $row->address;?></td>
                                    <td><?= $row->city;?></td>
                                    <td>
                                    <?= $row->name;?><br/>
                                    <a href="tel:+91<?= $row->mobileno1; ?>"><?= $row->mobileno1;?></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="tel:+91<?= $row->mobileno2;?>"><?= $row->mobileno2;?></a>
                                    </td>
                                    <td><?= $row->profession;?></td>
                                    <!-- <td><?= $row->state;?></td> -->
                                    <td><?= $row->gstno;?></td>
                                    <td>
											<a href="<?= base_url('admin/contacts/'.$row->id);?>" ><i class="fa fa-pencil" aria-hidden="true"></i></a>&nbsp;&nbsp;&nbsp;
											<a href="<?= base_url('admin/deletecontact/'.$row->id);?>"  ><i class="fa fa-trash" style="color:red" aria-hidden="true"></i></a>
										</td>
                                   
                                </tr>
                                <?php ++$count; } } ?>
                                                
                            </tbody>
                        </table>
                </div>


            </div>                       
        </div>
    </div>
</div>
<script>
