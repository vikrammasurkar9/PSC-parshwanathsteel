<table style="width:100%">
    <tr>
        <td style="width:100%;text-align:left;" >
            <b>Term and Conditions:</b>
            <ol>
                <li>GST @ 18% applicable extra on all above rates.</li>  
                <li>All Above Rates Are Ex Our Shiroli Godown  Delivery/ For Full Load Quantity Site Delivery Negotiable.</li>
                <li>Rates Are Valid For SAME Day Only subject to Market Fluctuation.</li>
                <li>Unloading At Your End.</li>
                <li>Weight at our Weighbridge will be only Final for Invoicing. If you have any complaint related to weight should be notified to us within 48 hours & usage of material. Issue will be finalized immediately by our representative by personal visit at your site. One sided Debit note without intimation will not be accepted.</li>
                <li>Tolerance in weight of 5 kg / mt is universal & should be allowed.</li>
                <li>Payment Advance against order. For delay Payment Interest @ 24 % p.a.will be charged on due amount.</li>
                <li>Loading & Cutting Charges Extra At Actual , If applicable</li>
                <li>Payment Schedule is The Part Of Our Supply Contract & Should Clearly Be Mentioned On Your Purchase Order. Purchase Order Without Payment Release Schedule Term Will Not Be accepted. </li>
                <li>All our Terms Will Compulsorily Applicable To Every Your Purchase Order Either They Are mentioned in Your Purchase Order Or not.</li>
            </ol>
        </td>      
    </tr>
    <tr>                                
        <td style="text-align:right;">
            <br /><br />
            <h5>For <?= $firm->firm;?></h5>
        </td>              
    </tr>
</table>