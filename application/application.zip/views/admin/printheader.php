<table style="width:100%">
    <tr>
        <td style="width:1-0%;text-align:center;">
            <h1 style="color:brown;">PARSHWANATH ISPAT PVT LTD</h1>         
        </td>
    </tr>
    <tr class="border_bottom">
        <td style="text-align:center;" >
            120/1, P.B ROAD NH-4, NEAR MAHADIK PETROL PUMP SHIROLI (PULACHI), KOLHAPUR<br />
            Email - purchase@parshwanathsteel.com<br/>
            Tel - (0230) 2461285, 2460009 Mob - 9607815933, 9607095933<br/>
            <b>GSTIN - 27AAFCP4825L1Z2</b>
        </td>
    </tr>
</table>